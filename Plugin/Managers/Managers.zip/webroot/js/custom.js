$(document).ready(function () {
	$('.date').datetimepicker({  
	   	format: 'YYYY-MM-DD',
	   	widgetPositioning:{
            horizontal: 'auto',
            vertical: 'bottom'
        },
	});
	$('.datetime').datetimepicker({  
	   	format: 'YYYY-MM-DD HH:mm',
	   	widgetPositioning:{
            horizontal: 'auto',
            vertical: 'bottom'
        },
	});
    $('.month').datetimepicker({  
        format: 'YYYY-MM',
        widgetPositioning:{
            horizontal: 'auto',
            vertical: 'bottom'
        },
    });
    $('[data-tooltip="tooltip"]').tooltip({html: true}); 
    $('body').on('click','.edit_task',function () {
        var dataid = $(this).attr('data-id');
        var url = '/calendar/managers/tasks/edit';
        //alert(dataid);
        $.ajax({
            url: url, 
            method: "GET",
            data: { dataid : dataid},
            dataType: "html",
            success: function(result){
                $("#load_edit_task_form").html(result);
            }
        });
    });
    // Add error to task
    $('body').on('click','.add_error',function () {
        var dataid = $(this).attr('data-task');
        var url = '/calendar/managers/errors/add';
        //alert(dataid);
        $.ajax({
            url: url, 
            method: "GET",
            data: { dataid : dataid},
            dataType: "html",
            success: function(result){
                $("#load_add_error_form").html(result);
            }
        });
    });
    // View errors of task
    $('body').on('click', '.view_errors', function () {
        var taskid = $(this).attr('data-taskid');
        var url = '/calendar/managers/errors/tasks';
        $.ajax({
            url: url, 
            method: "GET",
            data: { taskid : taskid},
            dataType: "html",
            success: function(result){
                $("#load_errors_list").html(result);
            }
        });
    });
    // Add note for task
    $('body').on('click', '.add_note', function () {
        var taskid = $(this).attr('data-taskid');
        var url = '/calendar/managers/notes/add';
        $.ajax({
            url: url, 
            method: "GET",
            data: { taskid : taskid},
            dataType: "html",
            success: function(result){
                $(".add-note").html(result);
            }
        });
    });
    // View notes of task
    $('body').on('click', '.view_notes', function () {
        var taskid = $(this).attr('data-task');
        //alert(taskid);
        var url = '/calendar/managers/notes/tasks/';
        $.ajax({
            url: url, 
            method: "GET",
            data: { taskid : taskid},
            dataType: "html",
            success: function(result){
                $("#load_view_notes").html(result);
            }
        });
    });
    // $(this).bind("contextmenu", function(e) {
    //     e.preventDefault();
    //     alert('Xem làm chi thím!');
    // });
    // document.onkeydown = function(e) {
    //     if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 ||     e.keyCode === 117 || e.keycode === 17 || e.keycode === 85)) {//ctrl+u Alt+c, Alt+v will also be disabled sadly.
    //         alert('Bỏ đi thím!');
    //     }
    //     return false;
    // };
    $('#list-view').change(function () {
        $('.loading-tasks').fadeIn('slow');
        var project_id = $('.select_project').val();
        var role_id = $('#role_id').val();
        var user_id = $('.select_user').val();
        var status = $('.select_status').val();
        //alert(role_id);
        $.ajax({
            url: "/calendar/managers/tasks/ajax/", 
            method: "GET",
            data: { project_id : project_id, role_id : role_id, user_id : user_id, status : status},
            dataType: "html",
            success: function(result){
                $(".load").html(result);
            }
        });
        setTimeout(function(){$('.loading-tasks').fadeOut();},1000);
    });
    var window_height = $(window).outerHeight() - 190;
    $('.scroll-table').css({'max-height': window_height, 'min-height': window_height});
    $('.scroll-table-month').css({'max-height': window_height + 60, 'min-height': window_height + 60});
    //popover
    $(function () {
        $('[data-toggle="popover"]').popover({ html : true, placement: 'bottom', trigger: 'hover' });
    });
    // Add task
    $('body').on('click', '.add-task-td', function () {
        var start = $(this).attr('data-date');
        var user_id = $(this).attr('data-user');
        var user_name = $(this).attr('data-user-name');
        $('.start_time').val(start+' 08:00:00');
        $('.end_time').val(start+' 17:30:00');
        $(".user_id option[value='"+user_id+"']").attr("selected","selected");
        $('.user-name-task').text(user_name);
    });
    // Filter by status
    $('.month-title span').click(function () {
        $('.user-name span').fadeOut();
        $('.loading-tasks').fadeIn('slow');
        var id = $(this).attr('id');
        if(id != 'all'){
            $('.task-row').fadeOut(500);
            $('.task-row-'+id).fadeIn(500);
            var count = $('.task-row-'+id).length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        }else{
            $('.task-row').fadeIn(500);
            var count = $('.task-row').length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        }
        setTimeout(function(){$('.loading-tasks').fadeOut();},1000);
        setTimeout(function(){$('.alert_add_task').fadeOut();},2000);
    });
    // Filter task by role
    $('.group-list').change(function () {
        $('.user-name span').fadeOut();
        $('.loading-tasks').fadeIn('slow');
        $('.select-user').addClass('rolling');
        var group_id = $(this).val();
        var url = './users/users/ajax/';
        if (group_id != '') {
            $('.user-name').fadeOut(500);
            $('.group-'+group_id).fadeIn(500);
            var count = $('.group-'+group_id+' .task-row').length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        }else{
            $('.user-name').fadeIn(500);
            var count = $('.user-name .task-row').length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        };
        $.ajax({
            method:'GET',
            url:url,
            data:{group_id:group_id},
            success:function(data){
                $('.select-user').html(data);
                setTimeout(function(){$('.select-user').removeClass('rolling');},800);
                setTimeout(function(){$('.alert_add_task').fadeOut();},2000);
            }
        });
        setTimeout(function(){$('.loading-tasks').fadeOut();},1000);
    });
    // Filter by user
    $('.select-user').change(function () {
        $('.user-name span').fadeOut();
        $('.loading-tasks').fadeIn('slow');
        var user_id = $(this).val();
        if(user_id != ''){
            $('.user-name').fadeOut(500);
            $('.user-'+user_id).fadeIn(500);
            var count = $('.user-'+user_id+' .task-row').length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        }else{
            $('.user-name').fadeIn(500);
            var count = $('.user-name .task-row').length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        }
        setTimeout(function(){$('.loading-tasks').fadeOut();},1000);
        setTimeout(function(){$('.alert_add_task').fadeOut();},2000);
    });
    // Filter task by project
    $('.project-list').change(function () {
        $('.user-name span').fadeOut();
        $('.loading-tasks').fadeIn('slow');
        var projectid = $(this).val();
        if (projectid != '') {
            $('.task-row').fadeOut(500);
            $('.project-'+projectid).fadeIn(500);
            var count = $('.project-'+projectid).length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        }else{
            $('.task-row').fadeIn(500);
            var count = $('.task-row').length;
            $('body').append( '<div class="alert alert-success fade in alert-dismissable alert_add_task"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>'+count+' Tasks</strong></div>');
        }
        setTimeout(function(){$('.loading-tasks').fadeOut();},1000);
        setTimeout(function(){$('.alert_add_task').fadeOut();},2000);
    });
});
$('body').on('change','.confirm',function (ev){
    var url = '/calendar/managers/tasks/change_status/'+$(this).attr('taskid');
    var myform = $(this).closest(".edit_form");
    $(this).addClass('reload');
    //console.log(url);
    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'html',
        data: myform.serialize(),
        cache: false,
        success: function (data) {
            $('.load').load('# .load tr');
        },
        error: function(data){
	        $('.load').load('# .load tr');
	    }
    });
    ev.preventDefault();
});
// Xác nhận nộp tiền
$('body').on('change','.add_money',function (ev){
    var url = '/calendar/managers/funds/add';
    var add_form = $(this).closest(".funds_form");
    $(this).addClass('reload');
    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'html',
        data: add_form.serialize(),
        cache: false,
        success: function (data) {
            $('.tab-content').load('# .tab-pane');
        },
        error: function(data){
            $('.tab-content').load('# .tab-pane');
        }
    });
    ev.preventDefault();
});
// Chỉnh sửa nộp tiền
$('body').on('change','.edit_fund',function (ev){
    var url = '/calendar/managers/funds/edit/'+$(this).attr('fundid');
    var myform = $(this).closest(".edit_fund");
    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'html',
        data: myform.serialize(),
        cache: false,
        success: function (data) {
            $('.tab-content').load('# .tab-pane');
        },
        error: function(data){
            $('.tab-content').load('# .tab-pane');
        }
    });
    ev.preventDefault();
});
// Xem thông tin chi tiêu
$('.view-order').click(function () {
    var month_id = $(this).attr('month_id');
    //alert(month_id);
    var url = "/calendar/managers/orders/view/";
    $.ajax({
        url: url, 
        method: "GET",
        data: { month_id : month_id},
        dataType: "html",
        success: function(result){
            $(".load_view_order").html(result);
        }
    });
});
// Add my skill
$('body').on('change','.add-skill',function (ev){
    var url = '/calendar/managers/myskills/add';
    var add_form = $(this).closest(".add_skill");
    $(this).addClass('reload');
    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'html',
        data: add_form.serialize(),
        cache: false,
        success: function (data) {
            $('.load').load('# .load tr');
        },
        error: function(data){
            $('.load').load('# .load tr');
        }
    });
    ev.preventDefault();
});
// Edit my skill
$('body').on('change','.change_status',function (ev){
    var url = '/calendar/managers/myskills/edit/'+$(this).attr('skillid');
    var myform = $(this).closest(".update_skill");
    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'html',
        data: myform.serialize(),
        cache: false,
        success: function (data) {
            $('.load').load('# .load tr');
        },
        error: function(data){
            $('.load').load('# .load tr');
        }
    });
    ev.preventDefault();
});
// Popup doing tasks
$('.close-popup').click(function () {
    $('.popup-task .panel').toggleClass('hidden');
    var icon = $(this).find('i').attr('class');
    if(icon == 'glyphicon glyphicon-plus'){
        $(this).find('i')[0].setAttribute('class', 'glyphicon glyphicon-remove');
        $(this).css({'right': '5px'});
        $('.relative').css({'padding-bottom': '5px'});
    }else{
        $(this).find('i')[0].setAttribute('class', 'glyphicon glyphicon-plus');
        $(this).css({'right': '12px'});
    }
})
// Using vacation day
$('#EventType').change(function () {
    var type = $(this).val();
    //alert(type);
    if (type == 1) {
        $('.vacation').css({'display':'block'});
    }else{
        $('.vacation').css({'display':'none'});
    }
});